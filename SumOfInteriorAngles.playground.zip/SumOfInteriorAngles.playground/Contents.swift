import UIKit

class Program
{
    func interiors (edge1 : Int, edge2 : Double, edge3 : Int, edge4 : Int, edge5 : Int) -> Int
    {
        //let sum = 3 * 180 // (n-2)*180
        let n = 5
        let sum = (n-2)*180
        print(sum)
        
        return sum
    }
}

let result = Program()
result.interiors(edge1: 6, edge2: 10.5, edge3: 7, edge4: 5, edge5: 8)

